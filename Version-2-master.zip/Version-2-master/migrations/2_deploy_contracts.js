var TeamRecords = artifacts.require("./TeamRecords.sol");

module.exports = function (deployer) {
  deployer.deploy(TeamRecords);
};
